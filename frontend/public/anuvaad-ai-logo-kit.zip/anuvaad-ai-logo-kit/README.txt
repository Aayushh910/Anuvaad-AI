ANUVAAD AI - LOGO KIT
Colors: Indigo #1B1B3A | Saffron #F2A33A | Cream #F7F4EE | Text accent #E08A12
Font: Sora Bold (wordmark is already converted to outlines in the SVGs)

svg/
  logo-horizontal-light-theme.svg  icon + name, for LIGHT backgrounds
  logo-horizontal-dark-theme.svg   icon + name, for DARK backgrounds
  logo-horizontal-auto-theme.svg   switches with the OS light/dark setting
  icon-light-theme.svg             icon only (corner/small spaces), LIGHT backgrounds
  icon-dark-theme.svg              icon only, DARK backgrounds
  icon-auto-theme.svg              icon only, follows OS theme
  app-icon.svg                     icon on indigo rounded tile (app stores, social avatar)
png/   same logos as PNG (icons 512/1024, horizontal 1600 wide, app icon 512/1024)
favicon/  favicon.svg (auto light/dark), favicon.ico (16/32/48), PNGs, apple-touch-icon, site.webmanifest
demo/index.html  working example: header logo + corner icon + theme toggle

BROWSER TAB (paste in <head>)
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <link rel="icon" href="/favicon.ico" sizes="48x48">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">
  <link rel="manifest" href="/site.webmanifest">

WEBSITE HEADER, MANUAL THEME TOGGLE
  Use the light/dark pair and show one by [data-theme] (see demo/index.html).
  Note: *-auto-theme.svg follows the OS setting, not your site's toggle button.
